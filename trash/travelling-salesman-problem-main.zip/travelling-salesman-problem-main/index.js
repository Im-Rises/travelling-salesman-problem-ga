export * from './App/Genetics/population.js';
export * from './App/Genetics/map.js';
export * from './App/Genetics/next-gen.js';
